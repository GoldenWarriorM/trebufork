/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.automirrored.rounded

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.AutoMirrored.Rounded.AlignHorizontalLeft: ImageVector
    get() {
        if (_alignHorizontalLeft != null) {
            return _alignHorizontalLeft!!
        }
        _alignHorizontalLeft = materialIcon(name = "AutoMirrored.Rounded.AlignHorizontalLeft",
                autoMirror = true) {
            materialPath {
                moveTo(3.0f, 22.0f)
                lineTo(3.0f, 22.0f)
                curveToRelative(-0.55f, 0.0f, -1.0f, -0.45f, -1.0f, -1.0f)
                verticalLineTo(3.0f)
                curveToRelative(0.0f, -0.55f, 0.45f, -1.0f, 1.0f, -1.0f)
                horizontalLineToRelative(0.0f)
                curveToRelative(0.55f, 0.0f, 1.0f, 0.45f, 1.0f, 1.0f)
                verticalLineToRelative(18.0f)
                curveTo(4.0f, 21.55f, 3.55f, 22.0f, 3.0f, 22.0f)
                close()
                moveTo(20.5f, 7.0f)
                horizontalLineToRelative(-13.0f)
                curveTo(6.67f, 7.0f, 6.0f, 7.67f, 6.0f, 8.5f)
                verticalLineToRelative(0.0f)
                curveTo(6.0f, 9.33f, 6.67f, 10.0f, 7.5f, 10.0f)
                horizontalLineToRelative(13.0f)
                curveToRelative(0.83f, 0.0f, 1.5f, -0.67f, 1.5f, -1.5f)
                verticalLineToRelative(0.0f)
                curveTo(22.0f, 7.67f, 21.33f, 7.0f, 20.5f, 7.0f)
                close()
                moveTo(14.5f, 14.0f)
                horizontalLineToRelative(-7.0f)
                curveTo(6.67f, 14.0f, 6.0f, 14.67f, 6.0f, 15.5f)
                verticalLineToRelative(0.0f)
                curveTo(6.0f, 16.33f, 6.67f, 17.0f, 7.5f, 17.0f)
                horizontalLineToRelative(7.0f)
                curveToRelative(0.83f, 0.0f, 1.5f, -0.67f, 1.5f, -1.5f)
                verticalLineToRelative(0.0f)
                curveTo(16.0f, 14.67f, 15.33f, 14.0f, 14.5f, 14.0f)
                close()
            }
        }
        return _alignHorizontalLeft!!
    }

private var _alignHorizontalLeft: ImageVector? = null
